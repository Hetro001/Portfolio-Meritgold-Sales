/* ============================================================
   script.js — Aliyah Merit-Gold Portfolio
   Step 1: Navbar · Hamburger Menu · Scroll FX · Utilities
   ============================================================ */

'use strict';

/* ─── DOM References ────────────────────────────────────────── */
const navbar    = document.getElementById('navbar');
const hamburger = document.getElementById('hamburger');
const navLinks  = document.getElementById('nav-links');
const overlay   = document.getElementById('nav-overlay');
const yearSpan  = document.getElementById('year');
const allNavLinks = document.querySelectorAll('.nav-link');

/* ─── 1. Dynamic Copyright Year ──────────────────────────── */
if (yearSpan) {
  yearSpan.textContent = new Date().getFullYear();
}

/* ─── 2. Sticky Navbar (scroll-shadow) ───────────────────── */
/**
 * Adds / removes the `.scrolled` class on the navbar so we can
 * transition from a transparent bar to a frosted-glass dark bar.
 */
function handleNavbarScroll() {
  if (window.scrollY > 20) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
}

// Run once on load (in case of page refresh mid-scroll)
handleNavbarScroll();
window.addEventListener('scroll', handleNavbarScroll, { passive: true });

/* ─── 3. Hamburger Menu (mobile) ─────────────────────────── */
/**
 * Toggles the mobile nav panel open / closed.
 * Also toggles the overlay and manages aria attributes for a11y.
 */
function openMenu() {
  hamburger.classList.add('open');
  navLinks.classList.add('open');
  overlay.classList.add('visible');
  hamburger.setAttribute('aria-expanded', 'true');
  overlay.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden'; // prevent background scroll
}

function closeMenu() {
  hamburger.classList.remove('open');
  navLinks.classList.remove('open');
  overlay.classList.remove('visible');
  hamburger.setAttribute('aria-expanded', 'false');
  overlay.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}

function toggleMenu() {
  const isOpen = navLinks.classList.contains('open');
  isOpen ? closeMenu() : openMenu();
}

hamburger.addEventListener('click', toggleMenu);

// Close when overlay (backdrop) is clicked
overlay.addEventListener('click', closeMenu);

// Close when a nav link is clicked (smooth scroll + close panel)
allNavLinks.forEach(link => {
  link.addEventListener('click', () => {
    closeMenu();
  });
});

// Close on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && navLinks.classList.contains('open')) {
    closeMenu();
    hamburger.focus(); // return focus to trigger button
  }
});

/* ─── 4. Active Nav Link on Scroll ───────────────────────── */
/**
 * Uses IntersectionObserver to highlight the nav link that
 * corresponds to the section currently in view.
 */
const sections = document.querySelectorAll('section[id]');

const sectionObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      // Remove active from all
      allNavLinks.forEach(link => link.classList.remove('active'));

      // Add active to matching link
      const id = entry.target.getAttribute('id');
      const matchingLink = document.querySelector(`.nav-link[href="#${id}"]`);
      if (matchingLink) matchingLink.classList.add('active');
    }
  });
}, {
  threshold: 0.45, // section must be 45% visible to trigger
});

sections.forEach(section => sectionObserver.observe(section));

/* ─── 5. Responsive: Reset menu on resize ────────────────── */
/**
 * If the user resizes from mobile to desktop while menu is open,
 * close and reset it so nav-links revert to their flex-row layout.
 */
let resizeTimer;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (window.innerWidth > 768) {
      closeMenu();
    }
  }, 150);
});

/* ─── 6. Smooth Scroll Polyfill (for older Safari) ───────── */
/**
 * CSS `scroll-behavior: smooth` covers most browsers.
 * This JS fallback handles anchor clicks for any browser that
 * doesn't yet support it natively.
 */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (!target) return;

    // Only intercept if native smooth scroll isn't working
    if (!('scrollBehavior' in document.documentElement.style)) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

/* ─── 7. Page-load animation guard ───────────────────────── */
/**
 * The CSS animations on [data-animate] elements use `forwards`
 * fill mode, so they persist after running. No JS needed for
 * the initial load sequence — this just ensures the body is
 * visible once fonts are ready.
 */
document.addEventListener('DOMContentLoaded', () => {
  document.body.style.visibility = 'visible';
});

/* ─── End of script.js ─────────────────────────────────── */
